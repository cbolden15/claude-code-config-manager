# Claude Code Config Manager (CCM)

## Project Overview

Personal tool for managing Claude Code project configurations across multiple projects and machines.

**Architecture:** CLI + Server
- **Server** runs on homelab (Docker), hosts web UI and API
- **CLI** runs on laptop/desktop, talks to server API, writes files locally
- **No authentication** — relies on network-level trust (local network / Tailscale)

**Core Workflow:**
```bash
ccm init my-project --profile blockchain
# → CLI calls server API
# → Server returns file contents
# → CLI writes .claude/, .mcp.json, etc. to local filesystem
# → CLI registers project with server
```

---

## Key Documents

| Document | Location | Description |
|----------|----------|-------------|
| Full Specification | `docs/SPECIFICATION.md` | Complete 1200+ line spec with all details |
| UI Mockup | `docs/UI-MOCKUP.html` | Interactive HTML mockup of all screens |

**Always read the relevant spec section before implementing a feature.**

---

## Technology Stack

| Layer | Technology |
|-------|------------|
| Frontend | Next.js 14 (App Router) |
| UI Components | shadcn/ui + Tailwind CSS |
| Database | SQLite |
| ORM | Prisma |
| CLI | Node.js + Commander.js + TypeScript |
| Package Manager | pnpm (workspaces) |
| Deployment | Docker |

---

## Repository Structure

```
claude-code-config-manager/
├── packages/
│   ├── server/                 # Next.js application
│   │   ├── src/
│   │   │   ├── app/           # Pages and API routes
│   │   │   ├── components/    # React components
│   │   │   └── lib/           # Utilities, generators, validators
│   │   ├── prisma/
│   │   │   ├── schema.prisma
│   │   │   └── seed.ts
│   │   └── package.json
│   │
│   ├── cli/                    # CLI tool
│   │   ├── src/
│   │   │   ├── index.ts       # Entry point
│   │   │   ├── commands/      # Command implementations
│   │   │   └── lib/           # API client, config, file utils
│   │   ├── bin/
│   │   │   └── ccm.js
│   │   └── package.json
│   │
│   └── shared/                 # Shared types and schemas
│       ├── src/
│       │   ├── types/
│       │   └── schemas/
│       └── package.json
│
├── docker/
│   ├── Dockerfile
│   └── docker-compose.yml
│
├── docs/
│   ├── SPECIFICATION.md       # Full project spec
│   └── UI-MOCKUP.html         # Interactive mockup
│
├── pnpm-workspace.yaml
├── package.json
└── CLAUDE.md                   # This file
```

---

## Current Phase

**Phase:** 1 - Project Scaffold
**Status:** Not started
**Next:** Set up monorepo with pnpm workspaces

### Phase Checklist

- [ ] **Phase 1: Scaffold** — Monorepo setup, Next.js, Prisma, shadcn/ui
- [ ] **Phase 2: Database** — Prisma schema, migrations, seed data
- [ ] **Phase 3: API Routes** — Components, profiles, projects, generate endpoints
- [ ] **Phase 4: UI Pages** — Dashboard, components, profiles, projects, monitoring, settings
- [ ] **Phase 5: CLI** — Config, list, init, apply, sync commands
- [ ] **Phase 6: Docker** — Dockerfile, compose, deployment docs

---

## Commands

```bash
# Install dependencies (from root)
pnpm install

# Development
pnpm dev                          # Run server in dev mode
pnpm --filter server dev          # Run only server
pnpm --filter cli dev             # Run CLI in watch mode

# Database
pnpm --filter server db:push      # Push schema changes
pnpm --filter server db:migrate   # Run migrations
pnpm --filter server db:studio    # Open Prisma Studio
pnpm --filter server db:seed      # Seed database

# Building
pnpm build                        # Build all packages
pnpm --filter cli build           # Build CLI only

# CLI (after building)
pnpm --filter cli start           # Run CLI
# Or after npm link:
ccm --help
```

---

## Conventions

### TypeScript
- Strict mode enabled everywhere
- Use `type` for object shapes, `interface` for extendable contracts
- Prefer `const` assertions for literal types

### Validation
- Use Zod for all runtime validation
- Define schemas in `packages/shared/src/schemas/`
- Validate API request bodies and CLI inputs

### Database
- Use Prisma client from `packages/server/src/lib/db.ts` (singleton)
- Store JSON in TEXT columns, parse with Zod on read
- Use transactions for multi-step operations

### API Routes
- Follow REST conventions
- Return consistent error format: `{ error: string, details?: unknown }`
- Use proper HTTP status codes

### UI Components
- Use shadcn/ui components (already installed)
- Follow the mockup in `docs/UI-MOCKUP.html` for layout and styling
- Use Tailwind classes, avoid custom CSS

### File Generation
- Generator functions live in `packages/server/src/lib/generators/`
- Each Claude Code primitive has its own generator
- Return `{ path: string, content: string }[]`

---

## Data Model Quick Reference

See `docs/SPECIFICATION.md` section 8 for full schema.

### Component Types
```typescript
enum ComponentType {
  MCP_SERVER      // .mcp.json entries
  SUBAGENT        // .claude/agents/*.md
  SKILL           // .claude/skills/*/SKILL.md
  COMMAND         // .claude/commands/*.md
  HOOK            // settings.json hooks array
  CLAUDE_MD_TEMPLATE  // CLAUDE.md templates
}
```

### Key Tables
- `Component` — Reusable config elements (MCP servers, subagents, etc.)
- `Profile` — Bundles of components for project types
- `Project` — Tracked projects with sync status
- `MonitoringEntry` — Ecosystem updates from n8n

### Component Config Schemas

**MCP Server:**
```typescript
{
  command: string;           // e.g., "npx"
  args: string[];           // e.g., ["-y", "@mcp/server-github"]
  env?: Record<string, string>;
  requiredSecrets?: string[];
}
```

**Subagent:**
```typescript
{
  name: string;
  description: string;
  tools?: string[];         // e.g., ["Read", "Edit", "Bash"]
  model?: string;
  instructions: string;     // Markdown body
}
```

**Skill:**
```typescript
{
  name: string;
  description: string;
  triggers?: string[];
  instructions: string;
}
```

**Command:**
```typescript
{
  name: string;             // Without slash
  description: string;
  prompt: string;
}
```

**Hook:**
```typescript
{
  hookType: 'SessionStart' | 'PreToolUse' | 'PostToolUse' | ...;
  matcher?: string;         // Regex for tool matching
  command: string;          // Shell command to run
  description?: string;
}
```

---

## API Endpoints Quick Reference

See `docs/SPECIFICATION.md` section 9 for full details.

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/components` | List components (with ?type= filter) |
| POST | `/api/components` | Create component |
| GET | `/api/components/[id]` | Get single component |
| PUT | `/api/components/[id]` | Update component |
| DELETE | `/api/components/[id]` | Delete component |
| GET | `/api/profiles` | List profiles |
| POST | `/api/profiles` | Create profile |
| GET | `/api/profiles/[id]` | Get profile with components |
| PUT | `/api/profiles/[id]` | Update profile |
| DELETE | `/api/profiles/[id]` | Delete profile |
| GET | `/api/projects` | List projects |
| POST | `/api/projects` | Register project |
| PUT | `/api/projects/[id]` | Update project |
| POST | `/api/projects/[id]/sync` | Mark as synced |
| **POST** | **`/api/generate`** | **Generate files for profile** |
| GET | `/api/monitoring` | List monitoring entries |
| POST | `/api/monitoring` | Add entry (from n8n) |
| GET | `/api/export` | Export all data |
| POST | `/api/import` | Import data |
| GET | `/api/health` | Health check |

---

## CLI Commands Quick Reference

See `docs/SPECIFICATION.md` section 10 for full details.

```
ccm
├── config
│   ├── set <key> <value>     # Set serverUrl, machine, defaultProfile
│   ├── get <key>             # Get config value
│   └── list                  # Show all config
│
├── init [name]               # Scaffold new project
│   ├── --profile, -p         # Profile to use
│   └── --dry-run            # Preview without writing
│
├── apply                     # Configure existing project
│   ├── --profile, -p         # Profile to apply
│   └── --force, -f          # Overwrite existing
│
├── list
│   ├── profiles             # List available profiles
│   ├── components           # List components
│   └── projects             # List tracked projects
│
├── sync                      # Update project to latest
│   └── --all                # Sync all on this machine
│
├── status                    # Show project status
│
└── export                    # Export project config
    └── --output, -o         # Output file path
```

CLI config stored at: `~/.config/ccm/config.json`

---

## Generated File Formats

When `ccm init` runs, it creates these files:

### .claude/CLAUDE.md
```markdown
# Project: {{projectName}}

## Overview
{{projectDescription}}

[Rest of template from profile]
```

### .claude/settings.json
```json
{
  "permissions": {
    "allow": ["Read", "Edit", "Create"],
    "deny": []
  },
  "hooks": { ... }
}
```

### .claude/agents/{{name}}.md
```markdown
---
name: Security Reviewer
description: Reviews code for security vulnerabilities
tools:
  - Read
  - Grep
model: claude-sonnet-4-20250514
---

[Instructions from component config]
```

### .claude/skills/{{name}}/SKILL.md
```markdown
---
name: API Documentation
description: Generates OpenAPI docs
triggers:
  - generate api docs
---

[Instructions from component config]
```

### .claude/commands/{{name}}.md
```markdown
---
name: deploy
description: Guided deployment workflow
---

[Prompt from component config]
```

### .mcp.json
```json
{
  "mcpServers": {
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_TOKEN": "${GITHUB_TOKEN}"
      }
    }
  }
}
```

---

## Testing

### API Testing
After implementing endpoints, test with curl:

```bash
# List components
curl http://localhost:3000/api/components

# Create component
curl -X POST http://localhost:3000/api/components \
  -H "Content-Type: application/json" \
  -d '{"type": "MCP_SERVER", "name": "github", ...}'

# Generate files
curl -X POST http://localhost:3000/api/generate \
  -H "Content-Type: application/json" \
  -d '{"profileId": "xxx", "projectName": "test"}'
```

### CLI Testing
```bash
# After building CLI
cd packages/cli && pnpm build && pnpm link --global

# Test commands
ccm config set serverUrl http://localhost:3000
ccm list profiles
ccm init test-project --profile general --dry-run
```

### Database Testing
```bash
# Open Prisma Studio to inspect data
pnpm --filter server db:studio
```

---

## Troubleshooting

### "Cannot find module" errors
```bash
pnpm install
pnpm build
```

### Prisma client not generated
```bash
pnpm --filter server db:push
```

### shadcn/ui component missing
```bash
cd packages/server
pnpm dlx shadcn-ui@latest add [component-name]
```

### Port already in use
```bash
lsof -i :3000
kill -9 [PID]
```

---

## Notes for Claude Code

1. **Always read the spec section before implementing** — The spec at `docs/SPECIFICATION.md` has all the details including exact schemas, API responses, and UI layouts.

2. **Match the mockup** — The HTML mockup at `docs/UI-MOCKUP.html` shows exactly how each screen should look.

3. **Test as you go** — Don't move to the next phase until current phase works. Use curl for APIs, Prisma Studio for database.

4. **Commit frequently** — After each working feature, suggest a git commit.

5. **Update this file** — After completing a phase, update the "Current Phase" section and check off the phase in the checklist.
