#!/bin/bash

# CCM Project Setup Script
# Run this in an empty directory to set up the project structure

set -e

echo "🚀 Setting up Claude Code Config Manager..."

# Create directory structure
mkdir -p docs
mkdir -p packages/server
mkdir -p packages/cli
mkdir -p packages/shared
mkdir -p docker

# Initialize git
git init

# Create pnpm workspace file
cat > pnpm-workspace.yaml << 'EOF'
packages:
  - 'packages/*'
EOF

# Create root package.json
cat > package.json << 'EOF'
{
  "name": "claude-code-config-manager",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "pnpm --filter server dev",
    "build": "pnpm -r build",
    "lint": "pnpm -r lint"
  },
  "devDependencies": {
    "typescript": "^5.3.0"
  },
  "engines": {
    "node": ">=20.0.0"
  }
}
EOF

# Create .gitignore
cat > .gitignore << 'EOF'
# Dependencies
node_modules/
.pnpm-store/

# Build outputs
dist/
.next/
out/

# Database
*.db
*.db-journal

# Environment
.env
.env.local
.env.*.local

# IDE
.idea/
.vscode/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
*.log
npm-debug.log*

# Test coverage
coverage/

# Prisma
packages/server/prisma/migrations/

# CLI config (don't commit user config)
# ~/.config/ccm/
EOF

# Create placeholder READMEs for packages
cat > packages/server/package.json << 'EOF'
{
  "name": "@ccm/server",
  "version": "1.0.0",
  "private": true
}
EOF

cat > packages/cli/package.json << 'EOF'
{
  "name": "@ccm/cli",
  "version": "1.0.0",
  "private": true
}
EOF

cat > packages/shared/package.json << 'EOF'
{
  "name": "@ccm/shared",
  "version": "1.0.0",
  "private": true
}
EOF

echo ""
echo "✅ Project structure created!"
echo ""
echo "📋 Next steps:"
echo ""
echo "   1. Copy your files into place:"
echo "      cp /path/to/CLAUDE.md ."
echo "      cp /path/to/SPECIFICATION.md docs/"
echo "      cp /path/to/UI-MOCKUP.html docs/"
echo ""
echo "   2. Start Claude Code:"
echo "      claude"
echo ""
echo "   3. Give Claude Code this prompt:"
echo "      \"Read CLAUDE.md, then read docs/SPECIFICATION.md sections 7 and 13."
echo "       Set up the full monorepo: Next.js 14 with App Router in packages/server,"
echo "       TypeScript CLI in packages/cli, shared types in packages/shared."
echo "       Install Prisma and shadcn/ui in the server package.\""
echo ""
EOF
